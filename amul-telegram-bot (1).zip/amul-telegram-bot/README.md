# Amul stock Telegram bot

Messages you on Telegram when Amul protein lassi (or anything else you watch)
comes back in stock on shop.amul.com for your pincode. Runs free on GitHub
Actions every 10 minutes, so your laptop can be off.

## Setup (about 10 minutes)

### 1. Create the bot
1. In Telegram, open **@BotFather** → `/newbot` → pick a name and username.
2. Copy the token it gives you (looks like `123456:ABC-...`). Keep it private.

### 2. Put the code on GitHub
1. Create a new **public** repository on github.com (see "Why public" below).
2. Upload everything in this folder, including the hidden `.github` folder.
   Easiest: on the empty repo page click "uploading an existing file" and
   drag the folder contents in. If `.github` doesn't upload, create the file
   `.github/workflows/amul.yml` by hand and paste its contents.

### 3. Add the token
Repo → **Settings → Secrets and variables → Actions**
- **Secrets** tab → New secret: `TELEGRAM_BOT_TOKEN` = your token.
- (Optional) **Variables** tab → `PINCODE` = your pincode. You can also set it from Telegram.

### 4. Claim the bot and start
1. Open your bot in Telegram and send `/start` — the first person to do this becomes its only user.
2. Send `/pincode 110001` (your pincode).
3. Repo → **Actions** tab → enable workflows if asked → "Amul stock check" → **Run workflow**.
   After ~2 minutes the bot replies. From then on it runs by itself every 10 minutes.

## Commands

| Command | What it does |
|---|---|
| `/pincode 110001` | Set delivery pincode |
| `/watch rose lassi` | Alert when any product name contains these words |
| `/unwatch rose lassi` | Stop watching |
| `/list` | Your watch words and current stock |
| `/stock` | Everything in stock right now |
| `/check` | Check now |

It watches `lassi` out of the box. On GitHub Actions, replies come at the next
scheduled run (up to ~10–15 min), not instantly.

## Why public, and is that safe?

GitHub Actions minutes are unlimited on public repos but capped at 2,000/month
on private ones; a check every 10 minutes needs ~6,000. Nothing personal is in
the repo: the token is a secret, and your pincode, chat and watch list live in
the Actions cache, which isn't visible to others. Only you can use the bot.

If you prefer a private repo, change the cron to `0 */2 * * *` (every 2 hours).

## Gotchas

- GitHub pauses scheduled workflows in public repos after 60 days without any
  commits. If alerts stop, open the Actions tab and re-enable it (or push any small change).
- GitHub sometimes starts scheduled runs late during busy hours.
- If Amul's checks fail 3 times in a row, the bot tells you and also when it recovers.

## Running it on your own machine instead (instant replies)

On any computer that stays on (a spare laptop, Raspberry Pi, cheap VPS):

```bash
npm install
npx playwright install --with-deps chromium
TELEGRAM_BOT_TOKEN=123:abc node bot.mjs serve
```

Replies are instant and it checks every 5 minutes (`CHECK_EVERY_MIN=10` to change).
Don't run this and the GitHub workflow at the same time — disable the workflow first.
